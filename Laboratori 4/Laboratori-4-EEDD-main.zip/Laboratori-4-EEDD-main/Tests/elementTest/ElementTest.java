package elementTest;

public interface ElementTest {
    void element();
}
