package addTest;

public interface AddTest {
    void addGreaterPriority();

    void addEqualPriority();

    void addNullCase();
}
