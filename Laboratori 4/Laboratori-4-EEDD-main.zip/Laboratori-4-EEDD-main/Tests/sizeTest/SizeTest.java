package sizeTest;

public interface SizeTest {
    void size();
}
