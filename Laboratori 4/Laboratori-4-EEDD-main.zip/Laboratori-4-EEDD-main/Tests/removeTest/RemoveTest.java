package removeTest;

import org.junit.jupiter.api.Test;

public interface RemoveTest {
    @Test
    void OneRemove();
    @Test
    void twoRemoves();
}
