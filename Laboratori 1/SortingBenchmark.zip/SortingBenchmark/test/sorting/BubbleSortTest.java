
package sorting;

/**
 * @author jmgimeno
 */
public class BubbleSortTest extends AbstractSortTest {

    @Override
    protected void doSort() {
        sorting.bubbleSort();
    }
}
